# pi-model-prompts

Short, model-selected guidance for Pi sessions and dispatch workers. These are
local prompting choices, not measured guarantees of better model performance.

## Install

```bash
cd /Users/pf/eden/tools/pi/extensions/pi-model-prompts
npm ci --ignore-scripts
npm run check
pi install /Users/pf/eden/tools/pi/extensions/pi-model-prompts
```

Run `/reload` in an existing Pi session after installation or rebuilding.
Pi loads `dist/index.js`; rebuild after source changes.

## Behavior

The `before_agent_start` hook reads `ctx.model` on every request and appends a
small guidance section without replacing the role or project instructions.
Unknown models are unchanged. Reapplying the same section is a no-op.

`pi-dispatch` depends on a packed copy of this package in its `vendor/` directory. Its in-process workers apply guidance
after resolving each model candidate, including fallback attempts. Child workers
explicitly load the extension, selecting guidance from the child's actual model.
Existing role prompts and task text remain intact. The optional scout, advisor,
and reviewer task builders are library utilities, not dispatch's integration path.

The packed dependency keeps dispatch's standalone checkout and CI installable
without publishing this package. After changing prompts, build and test here,
pack a new version with `npm pack --pack-destination ../pi-dispatch/vendor`, then
update dispatch's dependency and lockfile. The main session uses the local
directory installation above; rebuild it and run `/reload` after source changes.

## Recognized families

| Family | IDs (case-insensitive; provider/HF prefixes stripped) |
|---|---|
| Fable 5.1 | `claude-fable-5-1`, `claude-fable-5.1`, `fable-5.1` (including `neuralwatt/fable-5.1`) |
| Opus 5.5 | `claude-opus-5-5`, `claude-opus-5.5` |
| Sonnet 5.5 | `claude-sonnet-5-5`, `claude-sonnet-5.5` |
| GPT-6 Astra | `gpt-6-astra` and dash-suffixed variants |
| GPT-6.1 Sol | `gpt-6.1-sol` and dash-suffixed variants |
| GLM-5.3 | `glm-5.3` and dash-suffixed variants |
| Kimi K3 | `kimi-k3` and dash-suffixed variants |
| DeepSeek 4.1 | `deepseek-v4.1` and dash-suffixed variants |

Other versions intentionally do not inherit a different version's guidance.
For example, GPT-5.6 and DeepSeek V4 remain unchanged. GPT-6 Sol and Luna are
retired and also pass through unchanged.
Astra and 6.1 Sol share follow-through, blocker transparency, proportionate
verification, and plain-writing guidance from the [OpenAI guide](https://developers.openai.com/api/docs/guides/latest-model#prompting-best-practices).
Astra adds conditional delegation; 6.1 Sol adds hard restrictions, tool-failure
disclosure, and fact checking. See [GPT-6](docs/prompting-gpt-6.md).

Fable 5.1, Opus 5.5, and Sonnet 5.5 have distinct adaptations drawn from
Anthropic's guides; see [Fable](docs/prompting-claude-fable-5.1.md),
[Opus](docs/prompting-claude-opus-5.5.md), and
[Sonnet](docs/prompting-claude-sonnet-5.5.md). Opus 4.5 and Sonnet 5 support is removed.
Runtime features mentioned in those guides are not enabled by prompt text.

## Design and references

Inspired by [Aliou's model-family prompt selection](https://github.com/aliou/pi-harness/commit/f3394b52e7b77be847c98f550e525b775225c878).
That commit specializes subagent task prompts; this package additionally applies
short system guidance so existing dispatch roles need not be duplicated.

The notes in `docs/` explain local choices and link to provider references. They
are not an API configuration guide. This extension does not change reasoning
effort, sampling, context windows, caching, tools, or reasoning-history handling.
Permission boundaries and applicable project instructions always remain intact.
