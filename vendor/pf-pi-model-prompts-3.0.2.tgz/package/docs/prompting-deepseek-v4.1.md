# DeepSeek 4.1 prompting choices

Keep the task, context, constraints, and output requirements distinct. The optional
scout builder uses tagged sections for readability; tags are not a security
boundary. Request conclusions and concise evidence, not private reasoning.

These are local heuristics, not a claim that XML improves every DeepSeek task.
This package does not select Flash versus Pro, set thinking parameters, or
promise cache-hit rates.

Provider reference: [DeepSeek thinking mode](https://api-docs.deepseek.com/guides/thinking_mode).
Check the selected provider's documentation before changing runtime settings.
